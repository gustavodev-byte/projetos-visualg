Projetos de Lógica de Programação — VisualG

Cada arquivo .txt contém o texto de um código .ALG original, organizado por pasta/aula.
O arquivo TODOS_OS_CODIGOS.md reúne todos os códigos em um documento só, com separação por título.
Os arquivos originais .ALG não foram alterados; o conteúdo foi copiado para arquivos .txt.
